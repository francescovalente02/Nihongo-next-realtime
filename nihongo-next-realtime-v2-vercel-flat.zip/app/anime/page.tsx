export default function AnimePage(){
  return <div style={{background:'#141923', border:'1px solid #1f2633', borderRadius:10, padding:16}}>
    <h2>Anime consigliati</h2>
    <p>Integra AniList API per suggerimenti per livello + glossari mirati. Collega i progressi al sistema "Anime Unlock".</p>
  </div>
}
export default function Page(){
  return (
    <div style={{background:'#141923', border:'1px solid #1f2633', borderRadius:10, padding:16}}>
      <h1>Nihongo N4→N3 (Next.js + OpenAI Realtime)</h1>
      <p className="small">MVP demo: due sezioni (N4/N3), Trainer, Giochi, e una pagina Realtime per voce/chat live.</p>
    </div>
  )
}
export default function N4Page(){
  return <div style={{background:'#141923', border:'1px solid #1f2633', borderRadius:10, padding:16}}>
    <h2>Sezione N4</h2>
    <p>Percorso guidato: kanji base, grammatica essenziale, ascolto lento.</p>
  </div>
}
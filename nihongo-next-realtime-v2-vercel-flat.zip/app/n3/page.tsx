export default function N3Page(){
  return <div style={{background:'#141923', border:'1px solid #1f2633', borderRadius:10, padding:16}}>
    <h2>Sezione N3</h2>
    <p>Percorso N3: vocabolario intermedio, letture più complesse, dialoghi naturali.</p>
  </div>
}
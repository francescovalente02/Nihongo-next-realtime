# Deploy rapido (GitHub → Vercel)

1. **Carica tutti i file** di questa cartella in un nuovo repo GitHub (radice del repo deve contenere `package.json`, `app/`, `public/`).
2. Su **Vercel → Add New Project → Import Git Repository**.
3. **Environment Variables**:
   - `OPENAI_API_KEY` = la tua chiave (facoltativa per /realtime; non serve per /percorso e streak).
   - opz.: `OPENAI_REALTIME_MODEL` = `gpt-4o-realtime-preview-2024-12-17`
4. **Framework**: Next.js (auto). **Build**: `next build` (auto). **Output**: automatico.
5. **Deploy** e apri l'URL.

Se vedi 404:
- Controlla che il repo **alla radice** contenga `package.json` e la cartella `app/`.
- Project Settings → **Root Directory** deve essere `/`.
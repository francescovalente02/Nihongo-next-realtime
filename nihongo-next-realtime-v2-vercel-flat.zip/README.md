

## Nuove feature
- **Streak “Puzzle di Tokyo”**: 10 pezzi → svela il quartiere e passa al successivo.
- **Percorso stile Duolingo**: capitoli con 6–7 lezioni ciascuno; solo qui lo streak aumenta.
- **Mascotte Sushi**: feedback motivazionale e animazioni leggere.
- Animazioni con **framer-motion**.
